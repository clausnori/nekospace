import { type NextRequest, NextResponse } from "next/server"
import { getDatabase } from "@/lib/mongodb"
import { verifyPassword, createToken, setAuthCookie } from "@/lib/auth"
import type { User, LoginData } from "@/lib/models/User"

export async function POST(request: NextRequest) {
  try {
    const body: LoginData = await request.json()

    if (!body.email || !body.password) {
      return NextResponse.json({ error: "Email and password are required" }, { status: 400 })
    }

    const db = await getDatabase()
    const collection = db.collection<User>("users")

    // Find user by email
    const user = await collection.findOne({ email: body.email })

    if (!user || !user.password) {
      return NextResponse.json({ error: "Invalid email or password" }, { status: 401 })
    }

    // Verify password
    const isValidPassword = await verifyPassword(body.password, user.password)

    if (!isValidPassword) {
      return NextResponse.json({ error: "Invalid email or password" }, { status: 401 })
    }

    // Check if user is active
    if (!user.isActive) {
      return NextResponse.json({ error: "Account is deactivated. Please contact support." }, { status: 403 })
    }

    // Update last login
    await collection.updateOne({ _id: user._id }, { $set: { lastLoginAt: new Date(), updatedAt: new Date() } })

    // Create JWT token
    const token = await createToken(user._id!.toString())

    // Set HTTP-only cookie
    await setAuthCookie(token)

    // Return user data without password
    const { password, ...userWithoutPassword } = user

    return NextResponse.json({
      message: "Login successful",
      user: userWithoutPassword,
    })
  } catch (error) {
    console.error("Error logging in:", error)
    return NextResponse.json({ error: "Login failed. Please try again." }, { status: 500 })
  }
}
