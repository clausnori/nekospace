import { NextResponse } from "next/server"
import type { NextRequest } from "next/server"
import { jwtVerify } from "jose"

const JWT_SECRET = new TextEncoder().encode(process.env.JWT_SECRET || "your-secret-key-change-in-production")

export async function middleware(request: NextRequest) {
  const { pathname } = request.nextUrl

  // Public routes that don't require authentication
  const publicRoutes = [
    "/",
    "/login",
    "/register",
    "/discover",
    "/artist",
    "/song",
    "/album",
    "/api/songs",
    "/api/albums",
    "/api/users",
    "/api/auth/login",
    "/api/auth/register",
    "/api/search",
  ]

  // Check if the route is public or matches public patterns
  const isPublicRoute = publicRoutes.some((route) => {
    if (route === pathname) return true
    if (pathname.startsWith(route + "/")) return true
    return false
  })

  // Allow public routes
  if (isPublicRoute) {
    return NextResponse.next()
  }

  // Protected routes require authentication
  const token = request.cookies.get("auth-token")?.value

  if (!token) {
    // Redirect to login for protected routes
    const loginUrl = new URL("/login", request.url)
    loginUrl.searchParams.set("redirect", pathname)
    return NextResponse.redirect(loginUrl)
  }

  try {
    // Verify the token
    await jwtVerify(token, JWT_SECRET)
    return NextResponse.next()
  } catch (error) {
    console.error("Token verification failed:", error)
    // Invalid token, redirect to login and clear the cookie
    const response = NextResponse.redirect(new URL("/login", request.url))
    response.cookies.delete("auth-token")
    return response
  }
}

export const config = {
  matcher: [
    /*
     * Match all request paths except for the ones starting with:
     * - _next/static (static files)
     * - _next/image (image optimization files)
     * - favicon.ico (favicon file)
     * - public folder files
     */
    "/((?!_next/static|_next/image|favicon.ico|public|uploads).*)",
  ],
}
